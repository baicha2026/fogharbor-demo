/** One cancellable read at a time; metadata is replaced, never merged or persisted. */
import type { ArchiveError, Result } from '../shared/errors';
import type { WebHistoryItem, WebHistoryPage } from '../shared/web-history';
export interface WebHistoryState {
    phase: WebHistoryPage['phase'] | 'paused' | 'unavailable' | 'error';
    items: WebHistoryItem[];
    refreshing: boolean;
    loadingMore: boolean;
    error?: ArchiveError;
}
export interface WebHistoryPort {
    getSnapshot(): WebHistoryState;
    subscribe(listener: () => void): () => void;
    refresh(more?: boolean): Promise<void>;
}
export declare class WebHistoryMonitor implements WebHistoryPort {
    private readonly read;
    private state;
    private listeners;
    private active;
    private disposed;
    private abort;
    private timer;
    constructor(read: (more: boolean, signal: AbortSignal) => Promise<Result<WebHistoryPage>>);
    getSnapshot: () => WebHistoryState;
    subscribe: (listener: () => void) => (() => void);
    private patch;
    pause(phase: 'paused' | 'loading' | 'unavailable', clear?: boolean): void;
    resume(): void;
    refresh(more?: boolean): Promise<void>;
    dispose(): void;
}
