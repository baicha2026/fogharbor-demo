import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ChatSnapshot, WorkImportReceipt } from '../shared/contracts';
import { type Result } from '../shared/errors';
import { HISTORY_SOURCE, type HistoryImportRequest } from '../shared/history-rpc';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'dsh-chat-bridge-history': {
            kind: typeof HISTORY_SOURCE;
            form: 'snapshot';
            sections: {
                name: string;
                text: string;
            }[];
            transfer: WorkImportReceipt & {
                identity: string;
            };
            snapshot: ChatSnapshot;
        };
    }
}
export declare class HistoryService extends TypertRemoteService {
    /** Keep lifecycle ownership at the plugin fiber, outside per-call Context rebinding. */
    private readonly runtime;
    private readonly jobs;
    private readonly lifetime;
    constructor(ctx: Context);
    importHistory(request: HistoryImportRequest, signal: AbortSignal): Promise<Result<WorkImportReceipt>>;
    private perform;
}
export declare function applyHistoryHost(ctx: Context): HistoryService;
