/**
 * Client half of `dsh-chat-bridge`: the plugin body the DSH web shell loads
 * lazily from `lib/client.js`.
 *
 * What it contributes through public slots:
 *  - a keyed entry in the `main` slot (`dsh-chat-bridge`) holding the chat panel;
 *  - an entry in the `sidebar.footer.action` list holding the sidebar "Chat"
 *    button and archive tools, which live under the project area;
 *  - one resident mode switch aligned across the Chat and Conversation panels;
 *  - its own locale namespace and a single plugin-owned stylesheet.
 *
 * Everything registered here is owned by this fiber: `slots.register` and
 * `slots.inject` install their disposers through the caller's context, and the
 * controller, desktop additions and stylesheet are released by `ctx.effect`, so
 * disabling the plugin removes the panel, the button, the style tag and the
 * subscriptions with no residue.
 *
 * `inject` names the Cordis services the body needs; the client module graph
 * additionally loads the layout, sidebar and locale bundles first through
 * `dsh.client.inject` in `package.json`.
 *
 * @module dsh-chat-bridge/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
/** Main-panel id; deliberately not the reserved `conversation` key. */
export declare const PANEL_ID: MainPanelId;
/** Cordis services required before this plugin may activate. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): Promise<void>;
