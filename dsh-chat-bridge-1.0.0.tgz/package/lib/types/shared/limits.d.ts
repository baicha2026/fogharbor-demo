/**
 * Central limits for the basic-stage plugin. Every size/count gate reads from
 * here so a limit is stated once and can be asserted by tests and documented
 * once in `docs/CONTRACTS.md`.
 *
 * All byte limits are UTF-8 byte counts, never string `.length` (which counts
 * UTF-16 code units and would let a 4-byte emoji pass a "5 MiB" gate).
 *
 * @module dsh-chat-bridge/shared/limits
 */
/** Hard limits enforced before and after parsing. */
export declare const LIMITS: {
    /**
     * Largest accepted plain history input (`.json` manual format, `.txt`, `.md`,
     * or pasted text), measured in UTF-8 bytes.
     */
    readonly manualInputBytes: number;
    /**
     * Largest accepted full local-archive JSON file. It carries both the raw
     * original text and the normalized history, so it is larger than the plain
     * input gate; the `original.text` inside it is still checked against
     * {@link LIMITS.manualInputBytes}.
     */
    readonly archiveFileBytes: number;
    /** Largest accepted number of structured messages in one import. */
    readonly maxMessages: 5000;
    /** Largest accepted archive title, in Unicode code points. */
    readonly maxTitleLength: 200;
    /** Largest accepted number of attachments on one message (metadata only). */
    readonly maxAttachmentsPerMessage: 64;
    /** Largest accepted length of one attachment name. */
    readonly maxAttachmentNameLength: 260;
    /** Largest accepted length of a source URL. */
    readonly maxSourceUrlLength: 2048;
    /** Largest accepted length of a conversation id. */
    readonly maxConversationIdLength: 256;
    /** Largest accepted length of a message `id`. */
    readonly maxMessageIdLength: 128;
    /** Largest accepted length of a message `model` label. */
    readonly maxModelLabelLength: 128;
};
/** Message-count style limits that are compared as integers. */
export type NumericLimitKey = 'maxMessages' | 'maxTitleLength' | 'maxAttachmentsPerMessage' | 'maxAttachmentNameLength' | 'maxSourceUrlLength' | 'maxConversationIdLength' | 'maxMessageIdLength' | 'maxModelLabelLength';
/** Byte-count limits, compared against encoded UTF-8 length. */
export type ByteLimitKey = 'manualInputBytes' | 'archiveFileBytes';
/**
 * Encode text as UTF-8 and return its byte length.
 * @param text - any string; surrogate pairs count as their UTF-8 width.
 * @returns the UTF-8 byte length.
 */
export declare function utf8ByteLength(text: string): number;
/**
 * Count Unicode code points (what a user perceives as "characters"), so an
 * emoji title is not charged twice.
 * @param text - any string.
 * @returns the code-point count.
 */
export declare function codePointLength(text: string): number;
