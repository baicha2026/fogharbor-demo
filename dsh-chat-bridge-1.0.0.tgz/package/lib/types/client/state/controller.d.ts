/**
 * Panel state controller.
 *
 * One instance lives for the plugin's lifetime, created in `apply()` and shared
 * by the main panel and the sidebar entry through the slot `inject` face. That
 * is also what makes "returning to the chat panel restores the selected archive
 * and an unsubmitted import draft" true: mounting a component never resets this
 * object.
 *
 * The controller owns:
 *  - the lazily opened archive repository (opened once, failure remembered);
 *  - the load/search/select lifecycle of the archive list and detail pane;
 *  - the import draft, including its byte gate, decode, preview and save steps;
 *  - the work-handoff preview request.
 *
 * It never touches IndexedDB, React, or the DOM directly: storage goes through
 * `ArchiveRepository`, file reading through the caller-supplied `readFile`,
 * downloads through the injected `download` function. That keeps every branch
 * testable in Node.
 *
 * @module dsh-chat-bridge/client/state/controller
 */
import type { ArchiveRepository, ArchiveSummary, ChatSnapshot, ManualFormat, NavigationPort, WebCarrierPort, WorkImportPort, WorkImportPreview, WorkspaceChoice } from '../../shared/contracts';
import { type ArchiveError, type Result } from '../../shared/errors';
import { type BuiltImport } from '../../import/build-snapshot';
import type { DshChatBridgeLocaleKey } from '../locales';
import { type TransferPreferences, type TransferPreferenceStore } from '../../storage/transfer-preferences';
/** Which surface the panel header currently represents. */
export type PanelMode = 'chat' | 'work';
/** Largest number of messages rendered on one page of the detail pane. */
export declare const PAGE_SIZE = 50;
/** How the archive list is doing. */
export interface ListState {
    phase: 'loading' | 'ready' | 'error';
    summaries: readonly ArchiveSummary[];
    error?: ArchiveError;
}
/** How the detail pane is doing. */
export interface DetailState {
    phase: 'idle' | 'loading' | 'ready' | 'error';
    archiveId?: string;
    snapshot?: ChatSnapshot;
    error?: ArchiveError;
    /** 1-based page index over the message list (or the single text block). */
    page: number;
}
/** Which input the import wizard is on. */
export type ImportOrigin = 'file' | 'paste';
/** One in-progress import, preserved across panel unmounts. */
export interface ImportDraft {
    origin: ImportOrigin;
    /** Mode selected for pasted text. */
    pasteMode: ManualFormat;
    pasteText: string;
    /** Base file name of the picked file, when any. */
    fileName?: string;
    /** Decoded text of the picked file, kept so a failed save can retry. */
    fileText?: string;
    /** Format the decoded text is being parsed as (changes when the user falls back to raw text). */
    fileFormat?: ManualFormat;
    step: 'input' | 'preview';
    busy: boolean;
    error?: ArchiveError;
    /** Set once parsing succeeded; the preview and the snapshot to save. */
    built?: BuiltImport;
    /** Editable title in the preview step. */
    title: string;
    /** Locale key of a notice to show after a successful save. */
    noticeKey?: string;
}
/** How the work-handoff dialog is doing. */
export interface WorkState {
    phase: 'loading' | 'ready' | 'error';
    requestId: string;
    archiveId: string;
    preview?: WorkImportPreview;
    error?: ArchiveError;
    /** A failed native handoff; the same request identity is retained for retry. */
    commitError?: ArchiveError;
    workspaces?: WorkspaceChoice[];
    acceptContext?: boolean;
    committing?: boolean;
    targetLocked?: boolean;
    preferenceAfterCommit?: TransferPreferences;
}
export interface WebCaptureState {
    id: string;
    phase: 'loading' | 'ready' | 'saving' | 'error';
    title: string;
    acceptedScope: boolean;
    acceptContext?: boolean;
    workspaceId?: string;
    workspaces?: WorkspaceChoice[];
    quick?: boolean;
    enableQuick?: boolean;
    noticeKey?: DshChatBridgeLocaleKey;
    built?: BuiltImport;
    error?: ArchiveError;
}
export interface TransferSettingsState {
    phase: 'loading' | 'ready' | 'error';
    workspaceId: string;
    quickEnabled: boolean;
    workspaces: WorkspaceChoice[];
    error?: ArchiveError;
}
/** Immutable view of everything the panel renders. */
export interface ChatBridgeState {
    /** Always `chat` while the panel is mounted; picking `work` navigates away. */
    mode: PanelMode;
    list: ListState;
    /** Unfiltered sidebar projection; manager searches never hide sidebar archives. */
    sidebarList?: ListState;
    search: string;
    detail: DetailState;
    archiveDialog?: 'list' | 'detail';
    draft?: ImportDraft;
    work?: WorkState;
    capture?: WebCaptureState;
    transferPreference?: TransferPreferences;
    transferWorkspace?: WorkspaceChoice;
    preferenceError?: ArchiveError;
    transferSettings?: TransferSettingsState;
    /** Result of the last navigation attempt, when it failed. */
    navigationError?: ArchiveError;
    /** Locale key of a one-line notice about the last completed operation. */
    noticeKey?: DshChatBridgeLocaleKey;
}
/** Capabilities the panel renders as explicit "not wired up" notes. */
export interface CapabilityReport {
    webCarrier: WebCarrierPort['capability'];
    workImport: WorkImportPort['capability'];
}
/** Collaborators the controller needs; all injectable for tests. */
export interface ChatBridgeDeps {
    /** Open (or reuse) the archive repository. Called lazily, once. */
    openRepository(): Promise<Result<ArchiveRepository>>;
    /** Panel navigation (public layout API). */
    navigation: NavigationPort;
    /** Web carrier seam, owned for the controller lifetime. */
    webCarrier: WebCarrierPort;
    transferPreferences?: TransferPreferenceStore;
    /** Build the work-import seam for a repository. */
    createWorkImporter(repository: ArchiveRepository): WorkImportPort;
    /** Persist one export to the user's disk. */
    download(fileName: string, text: string, mimeType: string): void;
    /** Clock, injectable for tests. */
    now(): Date;
    /** Id source for work-import requests, injectable for tests. */
    newRequestId(): string;
}
/** Panel controller. */
export declare class ChatBridgeController {
    private readonly deps;
    private state;
    private readonly listeners;
    private repository;
    private openingRepository;
    private repositoryError;
    private importer;
    private listGeneration;
    private detailGeneration;
    private disposed;
    private captureAbort;
    private preferenceWriteFailed;
    /**
     * @param deps - collaborators; see {@link ChatBridgeDeps}.
     */
    constructor(deps: ChatBridgeDeps);
    private reloadTransferPreference;
    private rememberTransferPreference;
    openTransferSettings(): Promise<void>;
    updateTransferSettings(workspaceId: string, quickEnabled: boolean): void;
    saveTransferSettings(): void;
    closeTransferSettings(): void;
    refreshTransferDestination(): Promise<void>;
    disableQuickTransfer(): void;
    private availableWorkspaces;
    /** Capability report for the "not wired up" notes. */
    get capabilities(): CapabilityReport;
    /**
     * Subscribe to state changes.
     * @param listener - change callback.
     * @returns unsubscribe.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Current state. The reference changes on every mutation, which is what
     * `useSyncExternalStore` requires.
     * @returns the current immutable state.
     */
    getSnapshot(): ChatBridgeState;
    /** Merge a partial change into the state and notify subscribers. */
    private patch;
    /**
     * Drop optional top-level fields (the only way to express "clear this" under
     * `exactOptionalPropertyTypes`).
     * @param keys - state keys to remove.
     */
    private clearKeys;
    /**
     * Open the archive repository once and remember the outcome.
     * @returns the repository or the remembered failure.
     */
    private ensureRepository;
    /**
     * Open the work-import seam once the repository exists.
     * @returns the seam or the repository failure.
     */
    private ensureImporter;
    /**
     * Reload the archive list for the current search text.
     *
     * A generation counter drops responses from a superseded query, so typing
     * quickly cannot let an older result overwrite a newer one.
     * @returns nothing; the list state is published.
     */
    refresh(): Promise<void>;
    /**
     * Update the title search and reload the list.
     * @param search - new search text.
     */
    setSearch(search: string): void;
    /**
     * Load one archive into the detail pane.
     * @param archiveId - local archive id.
     * @returns nothing; the detail state is published.
     */
    selectArchive(archiveId: string): Promise<void>;
    /**
     * Move the detail pane to another page of the message list.
     * @param page - 1-based page index; clamped to the available range.
     */
    setPage(page: number): void;
    /**
     * Leave the chat panel for the original conversation surface.
     *
     * This is a navigation action and nothing else: no session is created, no
     * history is moved, and no draft is submitted.
     */
    returnToWork(): void;
    /** Bring the chat panel to the front (used by the sidebar entry). */
    openChatPanel(): void;
    /** Navigate a validated website link without transferring messages or submitting a draft. */
    openWebConversation(url: string): void;
    /** Archive tools are opt-in dialogs; the web canvas stays resident underneath. */
    openArchiveManager(): void;
    openArchive(archiveId: string): void;
    closeArchiveManager(): void;
    /** Dismiss the current one-line notice. */
    clearNotice(): void;
    /** Dismiss the last navigation failure. */
    clearNavigationError(): void;
    /** Open the import wizard with a fresh draft. */
    openImport(): void;
    /** Read on a click; reviewed mode waits for confirmation, quick mode uses the stored policy. */
    captureWebConversation(review?: boolean): Promise<void>;
    setWebCaptureTitle(title: string): void;
    acceptWebCaptureScope(acceptedScope: boolean): void;
    acceptWebCaptureContext(acceptContext: boolean): void;
    chooseWebCaptureWorkspace(workspaceId: string): void;
    enableQuickTransfer(enableQuick: boolean): void;
    /** Force is used only when leaving/unloading the panel; an in-flight archive may already persist. */
    closeWebCapture(force?: boolean): void;
    /** Persist the reviewed snapshot first; late completion after navigation never opens work. */
    saveWebCaptureToWork(): Promise<void>;
    /** Close the import wizard. Nothing is written before the user confirms. */
    closeImport(): void;
    /**
     * Switch between the file and paste inputs.
     * @param origin - the input to show.
     */
    setImportOrigin(origin: ImportOrigin): void;
    /**
     * Change the mode pasted text is parsed as. The draft returns to the input
     * step so the user re-previews under the new mode.
     * @param mode - the selected manual format.
     */
    setPasteMode(mode: ManualFormat): void;
    /**
     * Update the pasted text.
     * @param text - the current textarea value.
     */
    setPasteText(text: string): void;
    /**
     * Update the editable preview title.
     * @param title - the current title field value.
     */
    setDraftTitle(title: string): void;
    /**
     * Parse the pasted text and move to the preview step.
     * @returns nothing; the draft state is published.
     */
    previewPaste(): Promise<void>;
    /** Gate a browser File before allocating its buffer; ignore a closed/replaced wizard. */
    readFile(file: Pick<File, 'name' | 'size' | 'arrayBuffer'>): Promise<void>;
    /**
     * Accept a picked file: gate its bytes, decode strictly, and preview it.
     * @param fileName - base file name reported by the file input.
     * @param bytes - the file's bytes.
     * @returns nothing; the draft state is published.
     */
    chooseFile(fileName: string, bytes: Uint8Array): Promise<void>;
    /**
     * Attach a failure produced outside the controller (for example a file read
     * that never yielded bytes) to the current draft.
     * @param error - the failure to show.
     */
    reportDraftError(error: ArchiveError): void;
    /**
     * Fall back to reading the current input as raw text.
     *
     * Offered only when a JSON parse failed: the user's bytes are re-previewed as
     * one unverified text block instead of the import silently downgrading.
     */
    reparseAsRawText(): Promise<void>;
    /**
     * Parse one input into a preview, routing full-archive documents to the
     * re-import path and everything else to the manual-import path.
     * @param text - decoded input text.
     * @param format - format to parse as.
     * @param fileName - base file name, when the input came from a file.
     */
    private runImport;
    /**
     * Apply the typed title to a manual input when the user already changed it.
     * @param input - the input to build from.
     * @param typed - the current title field value.
     * @returns the input with the typed title applied.
     */
    private withTitle;
    /**
     * Save the previewed draft into the local archives.
     *
     * A second click while the first save is in flight is ignored, so one double
     * click produces one archive. A failed save keeps the preview and the original
     * text in place so the user can retry without re-importing.
     * @returns nothing; the draft, list, and detail states are published.
     */
    saveDraft(): Promise<void>;
    /**
     * Rename one archive.
     * @param archiveId - local archive id.
     * @param title - the new title.
     * @returns a promise resolving to the failure, when there is one.
     */
    renameArchive(archiveId: string, title: string): Promise<ArchiveError | undefined>;
    /**
     * Delete one local archive record.
     * @param archiveId - local archive id.
     * @returns a promise resolving to the failure, when there is one.
     */
    deleteArchive(archiveId: string): Promise<ArchiveError | undefined>;
    /**
     * Export the archive's original text exactly as imported.
     * @param archiveId - local archive id.
     * @returns a promise resolving to the failure, when there is one.
     */
    exportOriginal(archiveId: string): Promise<ArchiveError | undefined>;
    /**
     * Export the full local-archive document.
     * @param archiveId - local archive id.
     * @returns a promise resolving to the failure, when there is one.
     */
    exportDocument(archiveId: string): Promise<ArchiveError | undefined>;
    /**
     * Shared export path for both output shapes.
     * @param archiveId - local archive id.
     * @param shape - `original` for the raw text, `document` for the wrapped JSON.
     * @returns the failure, when there is one.
     */
    private exportArchive;
    /**
     * Build the handoff preview for one archive.
     * @param archiveId - local archive id.
     * @returns nothing; the work state is published.
     */
    prepareWork(archiveId: string, transfer?: {
        workspaceId: string;
        acceptContext: boolean;
        autoCommit: boolean;
        quickEnabled: boolean;
    }): Promise<void>;
    /** Select only an existing registry workspace; no directory is created. */
    chooseWorkWorkspace(workspaceId: string): void;
    acceptWorkContext(accepted: boolean): void;
    /** Close the handoff dialog without creating anything. */
    closeWork(): void;
    /**
     * Commit a preview through the active adapter. A native commit creates a
     * persisted history context; errors preserve the source and retry identity.
     * @returns nothing; the work state is published.
     */
    commitWork(): Promise<void>;
    /** Release the seams. Called from the plugin's effect teardown. */
    dispose(): void;
}
/** Default id source for work-import requests. */
export declare function defaultRequestId(): string;
