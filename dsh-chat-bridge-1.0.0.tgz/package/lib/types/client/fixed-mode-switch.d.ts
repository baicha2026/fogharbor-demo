/** One resident switch for both panels; only owned spacers are added to native chrome. */
import type { ChatBridgeController } from './state/controller';
import type { Translate } from './presentation';
export interface FixedModeSwitch {
    sync(panelId: string | null, t: Translate): void;
    dispose(): void;
}
export declare function installFixedModeSwitch(controller: ChatBridgeController, schedule: () => void): FixedModeSwitch;
