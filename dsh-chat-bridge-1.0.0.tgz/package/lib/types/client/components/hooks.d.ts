/**
 * React binding for the state controller.
 *
 * `subscribe` and `getSnapshot` are wrapped in `useCallback` so the store
 * identity stays stable across renders — an inline pair would make React
 * resubscribe on every render.
 *
 * @module dsh-chat-bridge/client/components/hooks
 */
import type { ChatBridgeController, ChatBridgeState } from '../state/controller';
/**
 * Subscribe the calling component to the controller's state.
 * @param controller - the plugin's controller instance.
 * @returns the current state.
 */
export declare function usePanelState(controller: ChatBridgeController): ChatBridgeState;
