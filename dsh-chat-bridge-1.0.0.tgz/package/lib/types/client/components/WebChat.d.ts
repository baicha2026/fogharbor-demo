/** Official page container and host-owned controls; capture is explicitly user-triggered. */
import { type ReactNode } from 'react';
import type { PresentedWebCarrier } from '../../adapters/desktop-web-carrier';
import type { Translate } from '../presentation';
/** Controls live in the panel header, keeping the entire canvas for the guest. */
export declare function WebChatActions({ t, carrier, onCapture, onReview, onSettings, quickEnabled, captureDisabled }: {
    t: Translate;
    carrier: PresentedWebCarrier;
    onCapture?: () => void;
    onReview?: () => void;
    onSettings?: () => void;
    quickEnabled?: boolean;
    captureDisabled?: boolean;
}): ReactNode;
export declare function WebChat({ t, carrier }: {
    t: Translate;
    carrier: PresentedWebCarrier;
}): ReactNode;
