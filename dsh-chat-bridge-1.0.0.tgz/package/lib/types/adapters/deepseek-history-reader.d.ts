export declare function webHistoryScript(more?: boolean): string;
