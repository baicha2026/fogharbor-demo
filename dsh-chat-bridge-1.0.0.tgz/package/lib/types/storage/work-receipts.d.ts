/** Durable source-to-native links; contains metadata only, never credentials or text. */
import type { WorkImportReceipt } from '../shared/contracts';
import { type Result } from '../shared/errors';
export declare function readWorkReceipt(requestId: string): Promise<Result<WorkImportReceipt | undefined>>;
export declare function saveWorkReceipt(receipt: WorkImportReceipt): Promise<Result<undefined>>;
