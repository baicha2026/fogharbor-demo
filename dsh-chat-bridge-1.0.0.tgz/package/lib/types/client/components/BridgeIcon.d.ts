import type { ReactNode } from 'react';
import { type BridgeIconName } from '../icons';
export declare function BridgeIcon({ name }: {
    name: BridgeIconName;
}): ReactNode;
