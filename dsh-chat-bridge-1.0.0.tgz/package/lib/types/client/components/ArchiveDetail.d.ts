/**
 * Archive detail pane: provenance, completeness, attachment metadata, the body,
 * and the action row.
 *
 * Everything shown here is either stored metadata or the original text. The pane
 * states explicitly when a value is *not* known (no remote conversation id, no
 * verified speakers, metadata-only attachments) rather than leaving a blank that
 * could read as "fine".
 *
 * @module dsh-chat-bridge/client/components/ArchiveDetail
 */
import { type ReactNode } from 'react';
import type { ChatSnapshot } from '../../shared/contracts';
import { type DetailState } from '../state/controller';
import { type Translate } from '../presentation';
/** Props of {@link ArchiveDetail}. */
export interface ArchiveDetailProps {
    t: Translate;
    detail: DetailState;
    onRename: (snapshot: ChatSnapshot) => void;
    onDelete: (snapshot: ChatSnapshot) => void;
    onExportOriginal: (snapshot: ChatSnapshot) => void;
    onExportDocument: (snapshot: ChatSnapshot) => void;
    onToWork: (snapshot: ChatSnapshot) => void;
    onPage: (page: number) => void;
}
/**
 * Render the detail pane.
 * @param props - see {@link ArchiveDetailProps}.
 * @returns the detail card.
 */
export declare function ArchiveDetail(props: ArchiveDetailProps): ReactNode;
