/** Managed Desktop guest; user-triggered DOM capture has no credential/storage/network access. */
import type { WebCarrierPort } from '../shared/contracts';
import { type ArchiveError } from '../shared/errors';
import { type WebHistoryPort } from './web-history-monitor';
export declare const DEEPSEEK_WEB_URL = "https://chat.deepseek.com/";
export interface WebCarrierState {
    phase: 'idle' | 'starting' | 'loading' | 'ready' | 'error';
    url: string;
    error?: ArchiveError;
}
/** DOM-facing adapter is separate from the portable business Port. */
export interface PresentedWebCarrier extends WebCarrierPort {
    readonly history: WebHistoryPort;
    getSnapshot(): WebCarrierState;
    subscribe(listener: () => void): () => void;
    mount(host: HTMLElement): () => void;
    reload(): void;
}
/** Creates a desktop carrier, or an explicit unavailable adapter in a web-only host. */
export declare function createDesktopWebCarrier(): PresentedWebCarrier;
