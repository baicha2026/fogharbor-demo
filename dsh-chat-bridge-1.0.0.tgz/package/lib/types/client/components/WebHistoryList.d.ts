import { type ReactNode } from 'react';
import type { PresentedWebCarrier } from '../../adapters/desktop-web-carrier';
import type { ChatBridgeController } from '../state/controller';
import { type Translate } from '../presentation';
/** Website links and local archives remain separate; only an explicit transfer persists messages. */
export declare function WebHistoryList({ t, carrier, controller }: {
    t: Translate;
    carrier: PresentedWebCarrier;
    controller: ChatBridgeController;
}): ReactNode;
