/** Canonical, bounded webpage capture format. Contains no raw HTML or page storage. */
import type { WebConversationCapture } from '../shared/contracts';
import { type Result } from '../shared/errors';
export declare const WEB_CAPTURE_FORMAT = "dsh-chat-bridge.web-capture";
export declare const WEB_CAPTURE_ADAPTER = "deepseek-dom-2026-10-01";
/** Validate an untrusted page result using the same message/attachment limits as manual imports. */
export declare function validateWebCapture(value: unknown): Result<WebConversationCapture>;
/** Stable bytes exclude the local capture clock, so reading unchanged content deduplicates. */
export declare function serializeWebCapture(capture: WebConversationCapture): string;
export declare function parseWebCapture(text: string): Result<WebConversationCapture>;
