/** Host half: registers the standalone history-import Remote service. */
import type { Context } from '@deepseek-ai/cordis';
/** Package name, Client factory id and root Loader row id. */
export declare const name = "dsh-chat-bridge";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
