/**
 * The "turn into work" handoff dialog.
 *
 * It requires an existing workspace and an explicit decision to preserve the
 * full history as persisted quoted context. The native adapter never submits it.
 * Unavailable hosts show the pending adapter's disabled state. Capacity stays
 * not-estimated; no token budget or fits-in-context conclusion is invented.
 *
 * @module dsh-chat-bridge/client/components/WorkImportDialog
 */
import type { ReactNode } from 'react';
import type { ChatBridgeController, WorkState } from '../state/controller';
import { type Translate } from '../presentation';
/** Props of {@link WorkImportDialog}. */
export interface WorkImportDialogProps {
    t: Translate;
    controller: ChatBridgeController;
    work: WorkState;
}
/**
 * Render the handoff preview.
 * @param props - see {@link WorkImportDialogProps}.
 * @returns the dialog element.
 */
export declare function WorkImportDialog({ t, controller, work }: WorkImportDialogProps): ReactNode;
