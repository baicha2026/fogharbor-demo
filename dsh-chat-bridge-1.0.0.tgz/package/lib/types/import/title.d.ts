/**
 * Title normalization and export file-name sanitization.
 *
 * A title is user-visible metadata only: it never becomes a path, never reaches
 * storage as an unvalidated value, and never touches the archive fingerprint.
 *
 * @module dsh-chat-bridge/import/title
 */
import { type Result } from '../shared/errors';
/** Fallback title when the source has neither a title nor a usable file name. */
export declare const FALLBACK_TITLE = "\u5BFC\u5165\u7684\u804A\u5929";
/**
 * Validate and normalize a user-supplied title.
 *
 * Surrounding whitespace is trimmed here (a title is a label, not archive
 * content, so trimming cannot lose imported data). The result is always
 * non-empty and within {@link LIMITS.maxTitleLength} code points.
 * @param raw - candidate title.
 * @returns the normalized title, or `INVALID_TITLE`.
 */
export declare function normalizeTitle(raw: string): Result<string>;
/**
 * Derive a starting title from a picked file's base name.
 *
 * Only the base name is used, so no directory from the user's machine can end
 * up in the archive.
 * @param fileName - base file name (as reported by the file input).
 * @returns a usable starting title.
 */
export declare function titleFromFileName(fileName: string): string;
/**
 * Turn a title into a safe download file name (no path separators, no control
 * characters, not a reserved device name, bounded length).
 * @param title - archive title.
 * @param extension - file extension including the dot, e.g. `.json`.
 * @returns a file name safe to hand to a download.
 */
export declare function safeExportFileName(title: string, extension: string): string;
