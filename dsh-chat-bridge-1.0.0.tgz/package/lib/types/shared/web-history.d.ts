import { type Result } from './errors';
export declare const WEB_HISTORY_LIMITS: {
    readonly items: 5000;
    readonly bytes: number;
    readonly title: 1024;
};
export interface WebHistoryItem {
    url: string;
    title: string;
}
export interface WebHistoryPage {
    scope: 'loaded-sidebar';
    phase: 'ready' | 'loading' | 'signed-out' | 'sidebar-closed';
    pageUrl: string;
    items: WebHistoryItem[];
    loadingMore: boolean;
}
/** Accept only the session routes observed in the supported official render code. */
export declare function webConversationUrl(value: string): string | undefined;
export declare function validateWebHistory(value: unknown): Result<WebHistoryPage>;
