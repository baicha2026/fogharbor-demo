import type { Translate } from './presentation';
export type ChatBridgeMode = 'work' | 'chat';
export interface ModePicker {
    readonly element: HTMLDivElement;
    update(mode: ChatBridgeMode, t: Translate): void;
    close(): void;
    dispose(): void;
}
export declare function createModePicker(onSelect: (mode: ChatBridgeMode) => void): ModePicker;
