/**
 * The chat panel registered into the host's `main` keyed slot.
 *
 * The web carrier fills the main canvas. Archive management/details are opt-in
 * dialogs entered from the sidebar; they never reserve a permanent web column.
 *
 * The mode switch is honest about what it does: "Chat" is the panel you are
 * looking at, and "Work" is a navigation action back to the original session
 * surface. It creates nothing and moves nothing.
 *
 * @module dsh-chat-bridge/client/components/ChatBridgePanel
 */
import { type ReactNode } from 'react';
import type { PresentedWebCarrier } from '../../adapters/desktop-web-carrier';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChatBridgeController } from '../state/controller';
/** Business face injected into the panel registration. */
export interface ChatBridgePanelFace {
    controller: ChatBridgeController;
    carrier?: PresentedWebCarrier;
}
/** Props assembled by the `main` slot renderer for this panel. */
export type ChatBridgePanelProps = Omit<PropsRuntime<'main'>, 'useWorkspaces'> & PropsLocale<'dshChatBridge'> & InjectFace<ChatBridgePanelFace>;
/**
 * Render the chat panel.
 * @param props - slot-composed props plus the injected controller.
 * @returns the panel element.
 */
export declare function ChatBridgePanel({ t, controller, carrier }: ChatBridgePanelProps): ReactNode;
