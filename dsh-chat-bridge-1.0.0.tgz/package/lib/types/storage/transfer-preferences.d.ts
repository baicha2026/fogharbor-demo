/** Host-origin metadata only. This key never contains chat text or website credentials. */
import { type Result } from '../shared/errors';
export declare const TRANSFER_POLICY: "rendered-context-v2";
export interface TransferPreferences {
    schemaVersion: 1;
    policy: typeof TRANSFER_POLICY;
    workspaceId: string;
    quickEnabled: boolean;
}
export interface TransferPreferenceStore {
    read(): Result<TransferPreferences | undefined>;
    write(value: TransferPreferences): Result<undefined>;
}
export declare function createTransferPreferenceStore(): TransferPreferenceStore;
