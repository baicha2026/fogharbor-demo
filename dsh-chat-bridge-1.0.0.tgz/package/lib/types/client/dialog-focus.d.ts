export declare function trapDialogTab(node: HTMLElement, event: Pick<KeyboardEvent, 'shiftKey' | 'preventDefault'>): void;
