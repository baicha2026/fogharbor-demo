/**
 * Paginated view over one structured history.
 *
 * Pagination is presentation only: the stored archive always holds every
 * message, and the pager states the totals so a reader can see that nothing was
 * dropped. Message bodies are rendered as text nodes — never as HTML — so a
 * message that contains markup stays literal.
 *
 * @module dsh-chat-bridge/client/components/MessagesView
 */
import type { ReactNode } from 'react';
import type { ImportedMessage } from '../../shared/contracts';
import type { Translate } from '../presentation';
/** Props of {@link MessagesView}. */
export interface MessagesViewProps {
    t: Translate;
    messages: readonly ImportedMessage[];
    page: number;
    pageSize: number;
    onPage: (page: number) => void;
}
/**
 * Render one page of messages plus its pager.
 * @param props - see {@link MessagesViewProps}.
 * @returns the message list.
 */
export declare function MessagesView({ t, messages, page, pageSize, onPage }: MessagesViewProps): ReactNode;
