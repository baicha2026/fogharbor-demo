/**
 * The "imported history" list: title search, the local archive rows, and the
 * entry point to the import wizard.
 *
 * Every row is explicitly labelled a local archive; nothing in this component
 * ever claims a remote or synced state.
 *
 * @module dsh-chat-bridge/client/components/ArchiveList
 */
import { type ReactNode } from 'react';
import type { ListState } from '../state/controller';
import { type Translate } from '../presentation';
/** Props of {@link ArchiveList}. */
export interface ArchiveListProps {
    t: Translate;
    list: ListState;
    search: string;
    selectedArchiveId: string | undefined;
    onSearch: (value: string) => void;
    onSelect: (archiveId: string) => void;
    onImport: () => void;
    onRefresh: () => void;
}
/**
 * Render the archive list card.
 * @param props - see {@link ArchiveListProps}.
 * @returns the list card.
 */
export declare function ArchiveList(props: ArchiveListProps): ReactNode;
