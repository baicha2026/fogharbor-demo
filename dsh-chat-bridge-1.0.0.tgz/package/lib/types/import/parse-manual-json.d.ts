/**
 * Parser for the plugin's own versioned manual-history JSON format.
 *
 * This format is this plugin's public contract. It is **not** a DeepSeek
 * export format: no official export shape is guessed at or accepted here. An
 * unknown JSON document is reported as unsupported so the user can choose to
 * re-read it as raw text; the importer never guesses fields and then claims a
 * faithful restore.
 *
 * @module dsh-chat-bridge/import/parse-manual-json
 */
import type { ImportedMessage } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** `format` value of the manual-history document. */
export declare const MANUAL_HISTORY_FORMAT = "dsh-chat-bridge.manual-history";
/** `format` value of a full local-archive document (see `archive-file.ts`). */
export declare const ARCHIVE_FORMAT = "dsh-chat-bridge.archive";
/** Schema version this build writes and accepts. */
export declare const MANUAL_HISTORY_SCHEMA_VERSION = 1;
/** A parsed, validated manual-history document. */
export interface ParsedManualHistory {
    /** Absent when the document had no usable title; the caller applies its own default. */
    title?: string;
    source: {
        url?: string;
        conversationId?: string;
    };
    completeness: 'user-supplied' | 'partial';
    messages: ImportedMessage[];
}
/**
 * Whether a JSON document announces the full local-archive wrapper.
 * Used to route a picked `.json` file to the right parser.
 * @param text - JSON text.
 * @returns true when the document's `format` field is the archive wrapper.
 */
export declare function looksLikeArchiveDocument(text: string): boolean;
/**
 * Parse and validate a manual-history document.
 *
 * Byte limits are checked here as well as at the input boundary, so a caller
 * that skipped the byte gate still cannot store an oversized archive.
 * @param text - the document text (already decoded from UTF-8).
 * @returns the validated history or a precise error.
 */
export declare function parseManualHistoryJson(text: string): Result<ParsedManualHistory>;
