/**
 * Turns one manual input into a saveable {@link ChatSnapshot}.
 *
 * This is the single place where "what the user handed us" becomes "what we
 * store": the original text is kept verbatim, the normalized history is derived
 * only from that text, and the content fingerprint is computed from the same
 * pair. The function is pure apart from id/time generation, so the import
 * wizard can build a preview without writing anything to storage.
 *
 * @module dsh-chat-bridge/import/build-snapshot
 */
import type { ChatSnapshot, Completeness, ImportedMessage, ManualFormat, SourceKind, WebConversationCapture } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** One raw manual input, already decoded from UTF-8 by the caller. */
export interface ManualInput {
    /** Format the user selected (or the one implied by the picked file). */
    format: ManualFormat;
    /** The decoded full text. */
    text: string;
    /** Base file name when the input came from a file; never a full path. */
    fileName?: string;
    /** Title the user typed in the preview; when absent a default is derived. */
    title?: string;
}
/** Attachment accounting shown in previews. */
export interface AttachmentSummary {
    /** Messages carrying at least one attachment. */
    messagesWithAttachments: number;
    /** Total attachment entries. */
    total: number;
    /** Entries marked `unavailable`. */
    unavailable: number;
    /** Names of the unavailable entries. */
    unavailableNames: string[];
}
/** Everything a preview screen needs, derived from a built snapshot. */
export interface ImportPreview {
    title: string;
    format: ManualFormat;
    sourceKind: SourceKind;
    fileName?: string;
    sourceUrl?: string;
    hasConversationId: boolean;
    historyKind: 'messages' | 'source-text';
    /** Message count for structured history. */
    messageCount?: number;
    /** Code points of the source text for unstructured history. */
    sourceTextLength?: number;
    /** UTF-8 bytes of the original text. */
    originalBytes: number;
    completeness: Completeness;
    attachments: AttachmentSummary;
    /** Locale keys for caveats the user must see before saving. */
    warningKeys: string[];
}
/** A built snapshot plus its preview projection. */
export interface BuiltImport {
    snapshot: ChatSnapshot;
    preview: ImportPreview;
}
/**
 * Reduce a picked file name to its base name.
 * @param fileName - raw name reported by the file input.
 * @returns the base name, or `undefined`.
 */
export declare function baseFileName(fileName: string | undefined): string | undefined;
/**
 * Count attachments across a structured history.
 * @param messages - imported messages.
 * @returns attachment accounting for previews.
 */
export declare function summarizeAttachments(messages: readonly ImportedMessage[]): AttachmentSummary;
/**
 * Build the preview projection for a snapshot.
 * @param snapshot - a built snapshot.
 * @returns the preview shown before saving and in the work-handoff dialog.
 */
export declare function previewOf(snapshot: ChatSnapshot): ImportPreview;
/**
 * Build a snapshot from one manual input.
 *
 * The returned snapshot is complete and validated, but nothing is stored: the
 * caller decides after the preview whether to save it.
 * @param input - decoded input.
 * @param now - injectable clock (used by tests).
 * @returns the snapshot plus preview, or a precise error.
 */
export declare function buildImport(input: ManualInput, now?: Date): Promise<Result<BuiltImport>>;
/** Build a schema v2 web archive without changing or migrating existing v1 manual archives. */
export declare function buildWebImport(capture: WebConversationCapture, now?: Date): Promise<Result<BuiltImport>>;
/**
 * Rebuild the expected fingerprint of a snapshot and compare it with the
 * stored one. Used by both the repository on write and the archive-file reader.
 * @param snapshot - snapshot to verify.
 * @returns the recomputed fingerprint, or `ARCHIVE_CORRUPTED` on mismatch.
 */
export declare function verifySnapshotFingerprint(snapshot: ChatSnapshot): Promise<Result<string>>;
/**
 * Re-derive the normalized history from a snapshot's original text and require
 * it to match what is stored. A record whose original and normalized halves
 * disagree is reported as corrupted instead of being trusted.
 * @param snapshot - snapshot to verify.
 * @returns success when the stored history is reproducible from the original.
 */
export declare function verifyHistoryConsistency(snapshot: ChatSnapshot): Result<undefined>;
