/**
 * Browser download helper.
 *
 * The file name always comes from `safeExportFileName`, which removes path
 * separators, control characters and reserved device names, so a user-chosen
 * archive title can never be interpreted as a path.
 *
 * @module dsh-chat-bridge/client/download
 */
/**
 * Save one text payload through an object URL.
 * @param fileName - a sanitized file name including its extension.
 * @param text - the exact text to write.
 * @param mimeType - MIME type with an explicit charset.
 */
export declare function downloadTextFile(fileName: string, text: string, mimeType: string): void;
