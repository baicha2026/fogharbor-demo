/** Version-scoped additions for native chrome holes that do not expose a Slot. */
import type { Context } from '@deepseek-ai/cordis';
import type { PresentedWebCarrier } from '../adapters/desktop-web-carrier';
import type { ChatBridgeController } from './state/controller';
/** Owns only added nodes and capture listeners; never replaces a host component. */
export declare function installDesktopLayout(ctx: Context, controller: ChatBridgeController, carrier: PresentedWebCarrier): () => void;
