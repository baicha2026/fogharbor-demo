import { type ReactNode } from 'react';
import type { Translate } from '../presentation';
import type { ChatBridgeController, WebCaptureState } from '../state/controller';
/** Page text is rendered as text nodes; website HTML never enters the host DOM. */
export declare function WebCaptureDialog({ t, controller, capture }: {
    t: Translate;
    controller: ChatBridgeController;
    capture: WebCaptureState;
}): ReactNode;
