/**
 * Dialog shell: modal semantics, Escape to close, a contained Tab cycle, focus
 * restoration, and a click-outside target. Every dialog in the plugin uses it,
 * so "Esc works" and "focus does not escape" are properties of one component
 * instead of three ad-hoc `<div>`s.
 *
 * @module dsh-chat-bridge/client/components/Modal
 */
import { type ReactNode } from 'react';
/** Props of {@link Modal}. */
export interface ModalProps {
    /** Dialog heading text; rendered by the dialog itself. */
    title: string;
    /** Localized name of the optional header close button. */
    closeLabel?: string;
    /** Close request from Escape or a click on the overlay. */
    onClose: () => void;
    /** Footer actions. */
    actions?: ReactNode;
    /** Additional plugin-owned sizing class. */
    className?: string;
    /** Dialog body. */
    children: ReactNode;
}
/**
 * Render a modal dialog.
 * @param props - see {@link ModalProps}.
 * @returns the dialog element.
 */
export declare function Modal({ title, closeLabel, onClose, actions, children, className }: ModalProps): ReactNode;
