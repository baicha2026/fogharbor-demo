/**
 * Runtime validation of a stored or imported {@link ChatSnapshot}.
 *
 * One validator serves both callers: the repository uses it to detect a
 * corrupted record (which must be reported, never auto-deleted) and the
 * archive-file reader uses it on a document a user supplied.
 *
 * @module dsh-chat-bridge/import/validate-snapshot
 */
import type { ChatSnapshot } from '../shared/contracts';
import { type ErrorCode, type Result } from '../shared/errors';
/**
 * Validate a manual v1 or web-capture v2 `ChatSnapshot`.
 * @param value - candidate value.
 * @param versionCode - error code for an unsupported `schemaVersion`.
 * @returns the validated snapshot or a precise error.
 */
export declare function validateSnapshot(value: unknown, versionCode?: ErrorCode): Result<ChatSnapshot>;
