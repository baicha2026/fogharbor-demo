/**
 * Source URL vetting.
 *
 * A source URL is provenance metadata, never a navigation target for this
 * stage (the basic build opens no links at all). Even so it is validated
 * strictly: only the official chat host over HTTPS, no credentials in the
 * authority, no dangerous scheme. The validated value is what gets stored;
 * the raw text the user pasted stays in `original.text`.
 *
 * @module dsh-chat-bridge/import/source-url
 */
import { type Result } from '../shared/errors';
/** The only accepted source host. */
export declare const SOURCE_HOST = "chat.deepseek.com";
/** The canonical source page used when a target needs one and none was given. */
export declare const SOURCE_ORIGIN = "https://chat.deepseek.com/";
/**
 * Validate a user-supplied source URL.
 *
 * Rejections (all reported as `UNSAFE_SOURCE_URL`): non-HTTPS schemes, hosts
 * other than {@link SOURCE_HOST} (including sub-domain look-alikes),
 * credentials in the authority, and over-long values.
 * @param raw - candidate URL text.
 * @returns the normalized URL string, or `UNSAFE_SOURCE_URL`.
 */
export declare function validateSourceUrl(raw: string): Result<string>;
/**
 * Validate a source conversation id.
 * @param raw - candidate id text.
 * @returns the trimmed id, or `INVALID_HISTORY` when unusable.
 */
export declare function validateConversationId(raw: string): Result<string>;
