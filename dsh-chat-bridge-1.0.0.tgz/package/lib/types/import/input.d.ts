/**
 * The manual-input boundary: what a picked file or a paste may be, how it is
 * size-gated, and which format it is routed to.
 *
 * The gate runs on raw bytes *before* decoding and again inside the parsers, so
 * an oversized input is refused rather than truncated, and a caller that skips
 * one check is still caught by the other.
 *
 * @module dsh-chat-bridge/import/input
 */
import type { ManualFormat } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** Which byte ceiling applies to an input. */
export type InputCeiling = 'manualInputBytes' | 'archiveFileBytes';
/**
 * Check a buffer against a ceiling before anything else happens.
 * @param byteLength - the buffer's UTF-8 byte length.
 * @param ceiling - which limit to apply.
 * @returns success, or `INPUT_TOO_LARGE` naming the limit.
 */
export declare function checkByteCeiling(byteLength: number, ceiling: InputCeiling): Result<undefined>;
/**
 * Route a picked file to a format by extension.
 * @param fileName - base file name reported by the file input.
 * @returns the format, or `UNSUPPORTED_FORMAT` for anything else.
 */
export declare function detectFormatFromFileName(fileName: string): Result<ManualFormat>;
/**
 * The input element's `accept` attribute, kept next to the accepted extensions
 * so the picker and the validator cannot drift apart.
 */
export declare const ACCEPT_ATTRIBUTE = ".json,.txt,.md,.markdown";
