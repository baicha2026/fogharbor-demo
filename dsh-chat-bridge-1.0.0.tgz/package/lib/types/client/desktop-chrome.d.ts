export type DesktopChrome = 'standard' | 'macos-windowed' | 'macos-fullscreen';
/** Keep the panel clear of native macOS controls, including after a fullscreen transition. */
export declare function useDesktopChrome(): DesktopChrome;
