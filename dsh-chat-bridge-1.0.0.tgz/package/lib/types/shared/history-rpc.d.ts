/** Handwritten public Typert boundary, shared by the standalone Host and Client. */
import type { InvocationDescriptor, RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { ChatSnapshot, WorkImportReceipt } from './contracts';
import { type Result } from './errors';
export declare const HISTORY_SERVICE = "dshChatBridgeHistory";
export declare const HISTORY_NAMESPACE = "dshChatBridge";
export declare const HISTORY_MODE: "imported-context";
export declare const HISTORY_SOURCE: "dsh-chat-bridge-history";
export interface HistoryImportRequest {
    requestId: string;
    workspaceId: string;
    acceptUnestimatedContext: true;
    snapshot: ChatSnapshot;
}
export interface HistoryRemote {
    importHistory(request: HistoryImportRequest, signal: AbortSignal): Promise<RemoteResult<Result<WorkImportReceipt>>>;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteNamespaceMap {
        dshChatBridge: HistoryRemote;
    }
}
export declare function historySessionId(requestId: string): string;
export declare function parseHistoryRequest(value: unknown): HistoryImportRequest;
/** This receipt is separate from the older quoted-draft receipts. */
export declare function isHistoryReceipt(value: unknown): value is WorkImportReceipt;
export declare const HISTORY_DESCRIPTORS: readonly InvocationDescriptor[];
export declare const HISTORY_REMOTE: TypertRemoteContribution;
