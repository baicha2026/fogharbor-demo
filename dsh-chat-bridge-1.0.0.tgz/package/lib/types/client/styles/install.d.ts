/**
 * Stylesheet installation and removal.
 *
 * The sheet lives in a single tagged `<style>` element. `installStyles`
 * returns an idempotent disposer that removes exactly that element, so
 * disabling the plugin leaves no rule behind — nothing else in the plugin is
 * allowed to write to `document.head`.
 *
 * @module dsh-chat-bridge/client/styles/install
 */
/**
 * Inject the plugin stylesheet once.
 * @param doc - document to install into; injectable for tests.
 * @returns an idempotent disposer removing the injected element.
 */
export declare function installStyles(doc?: Document): () => void;
