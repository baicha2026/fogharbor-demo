/**
 * Local-archive export and re-import.
 *
 * Two exports exist, and they are different things:
 *  - the **original text** file, which is exactly `original.text`, byte for
 *    byte (this is the user's own material back);
 *  - the **full local archive** JSON, wrapped as
 *    `{ format, schemaVersion, snapshot }`, which also carries the normalized
 *    history and metadata.
 *
 * Re-importing an archive never trusts it: the wrapper and snapshot are
 * re-validated, the fingerprint is recomputed, the normalized history is
 * re-derived from the original text and must agree with the stored one, and the
 * local identity is regenerated (a fresh `archiveId`/timestamps, deduplicated
 * afterwards by fingerprint). A document can therefore never dictate which
 * database row it writes to, and a renamed export does not overwrite the title
 * of an existing archive.
 *
 * @module dsh-chat-bridge/import/export-archive
 */
import type { ChatSnapshot } from '../shared/contracts';
import { type Result } from '../shared/errors';
import { type ImportPreview } from './build-snapshot';
import { ARCHIVE_FORMAT } from './parse-manual-json';
/** The full-archive document wrapper. */
export interface ArchiveDocument {
    format: typeof ARCHIVE_FORMAT;
    schemaVersion: 1 | 2;
    snapshot: ChatSnapshot;
}
/**
 * Serialize one snapshot as a full local-archive document.
 * @param snapshot - the archive to export.
 * @returns pretty-printed JSON text.
 */
export declare function serializeArchiveDocument(snapshot: ChatSnapshot): string;
/**
 * The text an "export original" download must contain.
 * @param snapshot - the archive to export.
 * @returns `original.text` unchanged.
 */
export declare function originalTextOf(snapshot: ChatSnapshot): string;
/** A re-imported archive plus the preview its new local identity implies. */
export interface ReimportedArchive {
    snapshot: ChatSnapshot;
    preview: ImportPreview;
}
/**
 * Parse a full local-archive document and rebuild it as a *new* local import.
 * @param text - document text (already decoded from UTF-8).
 * @param now - injectable clock (used by tests).
 * @returns the rebuilt snapshot or a precise error.
 */
export declare function parseArchiveDocument(text: string, now?: Date): Promise<Result<ReimportedArchive>>;
