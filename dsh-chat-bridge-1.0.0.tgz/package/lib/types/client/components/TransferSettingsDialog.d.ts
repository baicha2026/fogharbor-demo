import type { ReactNode } from 'react';
import type { ChatBridgeController, TransferSettingsState } from '../state/controller';
import type { Translate } from '../presentation';
export declare function TransferSettingsDialog({ t, controller, settings }: {
    t: Translate;
    controller: ChatBridgeController;
    settings: TransferSettingsState;
}): ReactNode;
