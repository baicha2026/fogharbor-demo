/** Closed, content-free diagnostics shared across the import boundary. */
import type { Err, ErrorCode, Result } from './errors';
export declare const BRIDGE_BUILD = "1.0.0";
export declare const IMPORT_STAGES: readonly ["client.prepare", "client.rpc", "client.receipt", "client.activate", "host.services", "host.validate", "host.workspace", "host.inspect", "host.preset", "host.model", "host.seed", "host.create", "host.mount", "host.publish", "host.activate", "host.attach", "host.title", "host.flush", "host.readback"];
export type ImportStage = typeof IMPORT_STAGES[number];
export declare const HISTORY_HOST_SERVICES: readonly ["sessions", "agents", "workspaceRegistry", "sessionController", "agentPresets", "agentDefaultModel", "sessionPersistence"];
export type HistoryHostService = typeof HISTORY_HOST_SERVICES[number];
declare const IMPORT_FAULTS: readonly ["gateway/ambiguous-endpoint", "gateway/arguments-invalid", "gateway/bad-request", "gateway/binding-invalid", "gateway/cancelled", "gateway/context-failed", "gateway/context-not-found", "gateway/context-unavailable", "gateway/definition-unavailable", "gateway/input-invalid", "gateway/internal", "gateway/invocation-unavailable", "gateway/lookup-failed", "gateway/lookup-not-found", "gateway/lookup-unavailable", "gateway/method-unavailable", "gateway/protocol", "gateway/provider-mismatch", "gateway/result-invalid", "gateway/service-unavailable", "gateway/signature-invalid", "gateway/uplink-overflow", "agent-preset/not-found", "agent-preset/invalid", "agent-preset/locked", "SessionPersistenceNotFoundError", "SessionAlreadyExistsError", "SessionAlreadyOwnedError", "SessionReadOnlyError", "SessionOwnershipLostError", "SessionHandleClosedError", "SessionPersistenceCorruptionError", "SessionFormatUnsupportedError", "EACCES", "EPERM", "ENOENT", "ENOSPC", "EBUSY", "EIO", "cordis/missing-inject", "cordis/inactive-service", "session/invalid-seed", "INACTIVE_EFFECT", "INVARIANT", "session/system-message-outside-step", "agent/factory-unavailable", "agent/default-model-api-unavailable", "agent/create-api-unavailable", "runtime/type-error", "runtime/range-error", "runtime/unclassified"];
export type ImportFault = typeof IMPORT_FAULTS[number];
export declare function importBuild(value: unknown): string | undefined;
export declare function importStage(value: unknown): ImportStage | undefined;
export declare function importFault(value: unknown): ImportFault | undefined;
export declare function historyHostService(value: unknown): HistoryHostService | undefined;
/** Search bounded wrapper causes for fixed codes; never copy exception data. */
export declare function faultOf(value: unknown): ImportFault;
/** Preserve a Host stage when a Client layer forwards the same business failure. */
export declare function importDiagnostic(result: Err, stage: ImportStage, fault?: ImportFault): Err;
export declare function importDiagnostic<T>(result: Result<T>, stage: ImportStage, fault?: ImportFault): Result<T>;
/** A setup callback can report its narrower stage without retaining the original exception. */
export declare class ImportStageFailure extends Error {
    readonly stage: ImportStage;
    readonly code: ErrorCode;
    readonly fault?: ImportFault | undefined;
    constructor(stage: ImportStage, code: ErrorCode, fault?: ImportFault | undefined);
    result(): Err;
}
export {};
