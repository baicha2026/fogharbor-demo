/**
 * The import wizard: pick a file or paste text, parse it, preview what would be
 * saved, then save on an explicit confirmation.
 *
 * Nothing is written before the confirmation click, and the step order in the
 * UI mirrors the pipeline exactly (byte gate → decode → parse → preview →
 * save). When a JSON input fails, the dialog offers an explicit fallback to
 * re-read the same bytes as raw text — the importer never downgrades silently.
 *
 * @module dsh-chat-bridge/client/components/ImportDialog
 */
import { type ReactNode } from 'react';
import type { ImportDraft, ChatBridgeController } from '../state/controller';
import { type Translate } from '../presentation';
/** Props of {@link ImportDialog}. */
export interface ImportDialogProps {
    t: Translate;
    controller: ChatBridgeController;
    draft: ImportDraft;
}
/**
 * Render the import wizard.
 * @param props - see {@link ImportDialogProps}.
 * @returns the dialog element.
 */
export declare function ImportDialog({ t, controller, draft }: ImportDialogProps): ReactNode;
