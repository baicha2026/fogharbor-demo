/**
 * Placeholder {@link WebCarrierPort}.
 *
 * The basic stage does not embed the official web chat: that needs the Desktop
 * Browser lease, a webview lifecycle, login handling, and navigation policy —
 * all of which belong to the next stage. What this file *does* provide is the
 * seam: a stable type, an explicit `unavailable` capability the UI must render,
 * and a `dispose()` that a real carrier will implement to release a guest.
 *
 * Replacement point for the next stage: keep this file's exported factory name
 * and return a different {@link WebCarrierPort} implementation; nothing else in
 * the plugin needs to change.
 *
 * @module dsh-chat-bridge/adapters/pending-web-carrier
 */
import type { CapabilityStatus, WebCarrierPort } from '../shared/contracts';
/** Capability report the UI shows instead of a fake connected state. */
export declare const WEB_CARRIER_CAPABILITY: CapabilityStatus;
/**
 * Create the placeholder carrier. Every `open()` call fails with
 * `WEB_CARRIER_NOT_IMPLEMENTED`; nothing is rendered and no navigation happens.
 * @returns the placeholder port.
 */
export declare function createPendingWebCarrier(): WebCarrierPort;
