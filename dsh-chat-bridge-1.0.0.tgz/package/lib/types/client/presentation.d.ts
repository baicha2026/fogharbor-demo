/**
 * Pure text helpers shared by the panel components: error rendering, enum
 * labels, and number formatting. Keeping them out of the components means both
 * dictionaries stay the single source of user-visible copy.
 *
 * @module dsh-chat-bridge/client/presentation
 */
import type { ArchiveSummary, CapabilityStatus, Completeness, ManualFormat, SourceKind } from '../shared/contracts';
import { type ArchiveError } from '../shared/errors';
import { type DshChatBridgeLocaleKey } from './locales';
/** The translate seat this plugin's registrations receive. */
export type Translate = (key: DshChatBridgeLocaleKey, params?: Record<string, unknown>) => string;
/**
 * Resolve one core-side string key to a typed dictionary key.
 * @param key - key reported by the core.
 * @returns the dictionary key, or `undefined` when this build defines no copy for it.
 */
export declare function coreKey(key: string): DshChatBridgeLocaleKey | undefined;
/**
 * Filter the core's caveat keys down to the ones this dictionary defines.
 * @param keys - keys reported by the core.
 * @returns typed dictionary keys, in the core's order.
 */
export declare function warningKeys(keys: readonly string[]): DshChatBridgeLocaleKey[];
/**
 * The capability note a seam publishes, as user-facing text. An unrecognized
 * note renders as nothing rather than as a raw key, and the caller decides
 * whether the line is shown at all.
 * @param t - namespace translate seat.
 * @param status - the seam's capability report.
 * @returns the note text, or an empty string when this build has no copy for it.
 */
export declare function capabilityText(t: Translate, status: CapabilityStatus): string;
/**
 * Render one error as user-facing text: the code's own sentence plus, when the
 * input named a field, that field path. Never includes user content.
 * @param t - namespace translate seat.
 * @param error - the failure to render.
 * @returns the message the user reads.
 */
export declare function errorText(t: Translate, error: ArchiveError): string;
/**
 * Label for a manual format.
 * @param t - namespace translate seat.
 * @param format - the original input format.
 * @returns the localized label.
 */
export declare function formatText(t: Translate, format: ManualFormat): string;
/**
 * Label for a source kind (the archive's provenance vocabulary).
 * @param t - namespace translate seat.
 * @param kind - source kind.
 * @returns the localized label; the kind is derived from the format.
 */
export declare function sourceKindText(t: Translate, kind: SourceKind): string;
/**
 * Sentence for a completeness value.
 * @param t - namespace translate seat.
 * @param completeness - the archive's completeness.
 * @returns the localized sentence.
 */
export declare function completenessText(t: Translate, completeness: Completeness): string;
/**
 * One-line size description for a list row.
 * @param t - namespace translate seat.
 * @param summary - the archive's list projection.
 * @returns a short description of how much content the archive holds.
 */
export declare function summarySizeText(t: Translate, summary: ArchiveSummary): string;
/**
 * Format a local timestamp for display without pulling in a date library.
 * @param iso - ISO-8601 string.
 * @returns a locale-formatted date/time, or the raw value when unparseable.
 */
export declare function formatTimestamp(iso: string): string;
/**
 * Count characters the way a reader does (code points, not UTF-16 units).
 * @param text - any string.
 * @returns the code-point count.
 */
export declare function characterCount(text: string): number;
/**
 * Build the failure reported when a picked file cannot be read at all.
 * Constructed here (rather than in a component) so no component creates error
 * literals of its own.
 * @returns a `FILE_READ_FAILED` error.
 */
export declare function fileReadError(): ArchiveError;
