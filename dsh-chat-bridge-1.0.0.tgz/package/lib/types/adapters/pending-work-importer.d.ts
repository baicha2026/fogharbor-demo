/**
 * {@link WorkImportPort} for the basic stage.
 *
 * `prepare()` is real: it reads the archive back from storage, re-verifies the
 * content fingerprint against what the caller expected, and builds the handoff
 * preview the UI shows. `commit()` is deliberately not implemented — creating a
 * work session needs a real workspace choice, context-budget handling, and a
 * native Session importer, none of which exist yet.
 *
 * Two rules the placeholder enforces so a later implementation cannot quietly
 * relax them:
 *  - no receipt is ever produced while `commit()` is unimplemented (the
 *    `receipts` array is exposed so a test can assert it stays empty);
 *  - the preview never states a token count, a model capacity, or a
 *    "fits in context" conclusion — `contextCapacity` is pinned to
 *    `not-estimated`, and `workspaceId` stays `null` because no workspace has
 *    been selected.
 *
 * @module dsh-chat-bridge/adapters/pending-work-importer
 */
import type { ArchiveRepository, CapabilityStatus, WorkImportPort, WorkImportPreview, WorkImportReceipt, WorkImportRequest } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** Capability report for the work-import seam. */
export declare const WORK_IMPORT_CAPABILITY: CapabilityStatus;
/** Archive-backed work-import seam with an explicitly unimplemented commit. */
export declare class PendingWorkImporter implements WorkImportPort {
    private readonly repository;
    readonly capability: CapabilityStatus;
    /**
     * Receipts this importer has produced. Always empty in this stage; a future
     * implementation appends exactly one per committed request.
     */
    readonly receipts: WorkImportReceipt[];
    private disposed;
    /**
     * @param repository - archive storage the preview is built from.
     */
    constructor(repository: ArchiveRepository);
    /**
     * Read the archive, verify it, and describe what a handoff would carry.
     * @param request - one user action's request.
     * @returns the preview, or a precise error.
     */
    prepare(request: WorkImportRequest): Promise<Result<WorkImportPreview>>;
    /**
     * Create a work session from a prepared archive.
     *
     * Always fails with `WORK_IMPORT_NOT_IMPLEMENTED`: no Agent, no Session, no
     * receipt, and no model call may result from this call.
     * @param _request - the request that was prepared.
     * @param _preview - the preview the user saw.
     * @returns always `WORK_IMPORT_NOT_IMPLEMENTED`.
     */
    commit(_request: WorkImportRequest, _preview: WorkImportPreview): Promise<Result<WorkImportReceipt>>;
    /** Release the seam; further `prepare()` calls fail explicitly. */
    dispose(): void;
}
/**
 * Create the pending importer.
 * @param repository - archive storage.
 * @returns the port.
 */
export declare function createPendingWorkImporter(repository: ArchiveRepository): WorkImportPort;
