/**
 * Small shared surfaces: an error banner and a dismissible notice.
 *
 * Errors are rendered with `role="alert"` so a screen reader announces them and
 * the failure is never a silent no-op.
 *
 * @module dsh-chat-bridge/client/components/Notices
 */
import type { ReactNode } from 'react';
import type { ArchiveError } from '../../shared/errors';
import { type Translate } from '../presentation';
/** Props of {@link ErrorBanner}. */
export interface ErrorBannerProps {
    t: Translate;
    error: ArchiveError;
    /** Optional dismiss handler; the banner is persistent without one. */
    onDismiss?: () => void;
}
/**
 * Render a failure with its code-specific sentence.
 * @param props - see {@link ErrorBannerProps}.
 * @returns the banner element.
 */
export declare function ErrorBanner({ t, error, onDismiss }: ErrorBannerProps): ReactNode;
/** Props of {@link NoticeBar}. */
export interface NoticeBarProps {
    t: Translate;
    /** Locale key of the notice text. */
    messageKey: Parameters<Translate>[0];
    onDismiss: () => void;
}
/**
 * Render a one-line informational notice.
 * @param props - see {@link NoticeBarProps}.
 * @returns the notice element.
 */
export declare function NoticeBar({ t, messageKey, onDismiss }: NoticeBarProps): ReactNode;
