/**
 * Chinese dictionary of this plugin's own namespace. Typed as a complete
 * `Record` of the English key union, so a missing or stray key is a compile
 * error rather than a raw key shown to the user.
 *
 * @module dsh-chat-bridge/client/locales/zh
 */
import type { DshChatBridgeLocaleKey } from './en';
export declare const zh: Record<DshChatBridgeLocaleKey, string>;
