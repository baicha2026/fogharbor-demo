@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 exit /b 1
if not exist "Fogharbor.exe" (
    echo Please extract the entire ZIP before starting the game.
    pause
    exit /b 1
)
start "" /wait "%~dp0Fogharbor.exe" %*
exit /b %errorlevel%
