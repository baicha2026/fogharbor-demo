/** Import persisted context through the plugin Host; never submits or writes input. */
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { IWorkspaces } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { IConversation } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { UiWorkspace } from '@deepseek-ai/dsh-client-ui-workspace/client';
import type { ArchiveRepository, ChatSnapshot, WorkImportPort } from '../shared/contracts';
import { type HistoryRemote } from '../shared/history-rpc';
export interface NativeWorkRuntime {
    sessions: ISessions;
    workspaces: IWorkspaces;
    conversation: IConversation;
    navigation: UiWorkspace;
    history?: HistoryRemote;
    beginNavigation(): AbortSignal;
    text(key: WorkDraftTextKey): string;
}
export type WorkDraftTextKey = 'work.quote.intro' | 'work.quote.attachments' | 'work.quote.task' | 'work.pendingTitlePrefix';
/** Legacy alpha.2–4 draft formatter, retained for compatibility; the importer no longer uses it. */
export declare function quotedHistoryDraft(snapshot: ChatSnapshot, text: NativeWorkRuntime['text']): string;
export declare function createNativeWorkImporter(repository: ArchiveRepository, runtime: NativeWorkRuntime): WorkImportPort;
