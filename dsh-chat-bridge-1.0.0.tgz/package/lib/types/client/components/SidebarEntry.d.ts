/**
 * The "Chat" entry in the sidebar's `sidebar.footer.action` list — the public
 * footer seat under the project area.
 *
 * The owner share tells the entry whether the column is wide or a 56px rail, so
 * the same component serves both: a labelled row with the local archive count in
 * wide mode, and an icon-only button with an accessible name and a tooltip in
 * rail mode. Selecting it opens this plugin's `main` panel; nothing else
 * happens, and no session is touched.
 *
 * @module dsh-chat-bridge/client/components/SidebarEntry
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChatBridgeController } from '../state/controller';
import type { PresentedWebCarrier } from '../../adapters/desktop-web-carrier';
/** Business face injected into the sidebar entry registration. */
export interface ChatEntryFace {
    controller: ChatBridgeController;
    carrier?: PresentedWebCarrier;
}
/** Props assembled by the `sidebar.footer.action` list renderer. */
export type ChatEntryProps = Omit<PropsRuntime<'sidebar.footer.action'>, 'useWorkspaces'> & PropsLocale<'dshChatBridge'> & InjectFace<ChatEntryFace>;
/**
 * Render the sidebar entry.
 * @param props - slot-composed props plus the injected controller.
 * @returns the entry element.
 */
export declare function ChatEntry({ t, controller, carrier, wide }: ChatEntryProps): ReactNode;
