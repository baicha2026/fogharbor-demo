/** No user-controlled code is interpolated; all options are plugin-owned constants. */
export declare function currentConversationScript(): string;
