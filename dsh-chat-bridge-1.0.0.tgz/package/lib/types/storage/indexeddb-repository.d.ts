/**
 * IndexedDB-backed {@link ArchiveRepository}: the real persistence of the
 * basic stage.
 *
 * Layout — one database, two object stores, one transaction:
 *  - `summaries` holds the list projection only (no message bodies), keyed by
 *    `archiveId`, with a **unique** `fingerprint` index and an `updatedAt`
 *    index. The unique index is what makes duplicate detection a database
 *    guarantee rather than a best-effort read-then-write.
 *  - `archives` holds the full {@link ChatSnapshot}, keyed by `archiveId`.
 *
 * The UI never touches IndexedDB: everything goes through the repository
 * interface, so a later host-side archive service can be swapped in without
 * changing a component.
 *
 * Failure policy: an unavailable database is reported as `STORAGE_UNAVAILABLE`
 * and never silently downgraded to memory (which would tell the user their
 * archive is safe when it is not). A corrupt or unknown-version record is
 * reported and never auto-deleted; the rest of the archive list stays usable.
 *
 * @module dsh-chat-bridge/storage/indexeddb-repository
 */
import type { ArchiveListQuery, ArchiveRepository, ArchiveSummary, ChatSnapshot, SaveOutcome } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** Database name; versioned so a future schema change is an explicit migration. */
export declare const DATABASE_NAME = "dsh-chat-bridge.archives.v1";
/** Schema version of the database (independent of the snapshot schema version). */
export declare const DATABASE_VERSION = 1;
/** Fields of a stored summary record (the projection plus its sort key). */
interface StoredSummary extends ArchiveSummary {
    /** Duplicated from the summary for an explicit sort key. */
    sortKey: string;
}
/**
 * Convert a validated snapshot into its list projection.
 * @param snapshot - a validated snapshot.
 * @returns the summary record to store.
 */
export declare function toSummary(snapshot: ChatSnapshot): StoredSummary;
/**
 * Build the list entry shown for a record this build cannot read. The record is
 * never deleted or hidden: the user must be able to see it and remove it.
 * @param archiveId - the record's key, when it had one.
 * @param messageKey - locale key describing the corruption.
 * @returns a `corrupted` list entry.
 */
export declare function corruptedSummary(archiveId: string, messageKey: string): ArchiveSummary;
/** IndexedDB-backed archive repository. */
export declare class IndexedDbArchiveRepository implements ArchiveRepository {
    private db;
    private disposed;
    /**
     * @param db - an already-open database handle.
     */
    private constructor();
    /**
     * Open the repository.
     * @param factory - `IDBFactory` to use; defaults to `globalThis.indexedDB`.
     * @returns the repository, or `STORAGE_UNAVAILABLE` when IndexedDB is absent
     * or cannot be opened.
     */
    static open(factory?: IDBFactory): Promise<Result<IndexedDbArchiveRepository>>;
    /** The live handle, or a failure when the repository was disposed. */
    private handle;
    /**
     * List archive summaries, newest first.
     * @param query - optional title search.
     * @returns summaries sorted by `updatedAt` descending, ties broken by id.
     */
    list(query?: ArchiveListQuery): Promise<Result<ArchiveSummary[]>>;
    /**
     * Read one archive.
     * @param archiveId - local archive id.
     * @returns the validated snapshot, `ARCHIVE_NOT_FOUND`, or `ARCHIVE_CORRUPTED`.
     */
    get(archiveId: string): Promise<Result<ChatSnapshot>>;
    /**
     * Save a snapshot, deduplicating by content fingerprint.
     * @param snapshot - the snapshot to store.
     * @returns the stored (or pre-existing) archive id and whether it is a duplicate.
     */
    save(snapshot: ChatSnapshot): Promise<Result<SaveOutcome>>;
    /**
     * Look up an archive id by fingerprint, used only to resolve a lost race.
     * @param fingerprint - content fingerprint.
     * @returns the archive id when present.
     */
    private findByFingerprint;
    /**
     * Rename an archive. Only the title and `updatedAt` change; the original
     * text, the normalized history, and the fingerprint are untouched.
     * @param archiveId - local archive id.
     * @param title - the new title.
     * @returns success, `ARCHIVE_NOT_FOUND`, or `INVALID_TITLE`.
     */
    rename(archiveId: string, title: string): Promise<Result<undefined>>;
    /**
     * Delete one archive record. Nothing outside this database is touched: no
     * source file, no remote conversation.
     * @param archiveId - local archive id.
     * @returns success or `ARCHIVE_NOT_FOUND`.
     */
    remove(archiveId: string): Promise<Result<undefined>>;
    /** Close the database handle. Later calls report `STORAGE_UNAVAILABLE`. */
    dispose(): void;
}
/**
 * Convenience opener returning the repository interface.
 * @param factory - `IDBFactory` to use; defaults to `globalThis.indexedDB`.
 * @returns the repository or `STORAGE_UNAVAILABLE`.
 */
export declare function openArchiveRepository(factory?: IDBFactory): Promise<Result<ArchiveRepository>>;
export {};
