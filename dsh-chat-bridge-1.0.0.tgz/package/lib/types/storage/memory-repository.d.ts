/**
 * In-memory {@link ArchiveRepository}.
 *
 * **This implementation does not persist anything.** It exists for unit tests
 * and, explicitly labelled as such, for a development preview where IndexedDB
 * is unavailable. The production client never falls back to it silently: an
 * unavailable database is reported as `STORAGE_UNAVAILABLE` so the user is
 * never told that an archive was saved when it was not.
 *
 * It implements the same contract as the IndexedDB repository — including
 * fingerprint deduplication, corruption reporting, and the exact same error
 * codes — so tests exercise the interface the UI actually depends on.
 *
 * @module dsh-chat-bridge/storage/memory-repository
 */
import type { ArchiveListQuery, ArchiveRepository, ArchiveSummary, ChatSnapshot, SaveOutcome } from '../shared/contracts';
import { type Result } from '../shared/errors';
/** Marker shown wherever this repository is used, so it can never be mistaken for real storage. */
export declare const MEMORY_REPOSITORY_NOTICE = "non-persistent test repository";
/** Volatile archive repository. */
export declare class MemoryArchiveRepository implements ArchiveRepository {
    private readonly archives;
    private readonly byFingerprint;
    private disposed;
    /**
     * @param options - test hooks; production code passes nothing.
     */
    constructor(options?: {
        readonly failWrites?: boolean;
    });
    /** When true every write reports `STORAGE_UNAVAILABLE`, to exercise failure paths. */
    private readonly failWrites;
    /**
     * List summaries, newest first.
     * @param query - optional title search.
     * @returns summaries sorted by `updatedAt` descending, ties broken by id.
     */
    list(query?: ArchiveListQuery): Promise<Result<ArchiveSummary[]>>;
    /**
     * Read one archive.
     * @param archiveId - local archive id.
     * @returns the validated snapshot or a precise error.
     */
    get(archiveId: string): Promise<Result<ChatSnapshot>>;
    /**
     * Save a snapshot with fingerprint deduplication.
     * @param snapshot - the snapshot to store.
     * @returns the stored or pre-existing id and whether it is a duplicate.
     */
    save(snapshot: ChatSnapshot): Promise<Result<SaveOutcome>>;
    /**
     * Rename an archive without touching its content.
     * @param archiveId - local archive id.
     * @param title - the new title.
     * @returns success or a precise error.
     */
    rename(archiveId: string, title: string): Promise<Result<undefined>>;
    /**
     * Delete one archive record.
     * @param archiveId - local archive id.
     * @returns success or `ARCHIVE_NOT_FOUND`.
     */
    remove(archiveId: string): Promise<Result<undefined>>;
    /** Drop all in-memory state. */
    dispose(): void;
    /**
     * Insert a record without validation, to simulate a corrupted database row.
     * Test-only helper; the production repository has no equivalent.
     * @param record - raw record to plant.
     */
    plantCorruptedRecord(record: unknown): void;
}
